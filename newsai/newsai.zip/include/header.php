    <!-- Mobile menu overlay mask -->
 <header id="plain">
        
        
        <div class="container">
        <div class="row">
        <div class="col-md-5 col-sm-5 col-xs-5">
                    <div><i class="icon_set_1_icon-90"></i> - +91 99214 99999                       
                    </div>
                </div>
                <div class="col-md-5 col-sm-5 col-xs-5">
                    <div>A Qualitative Experience is Assured                       
                    </div>
                </div>
        </div>
            <div class="row">
                <div class="col-md-3 col-sm-3 col-xs-3">
                    <div id="logo">
                        <a href="index.php"><img src="img/logo.png" width="120" height="80" alt="City tours" data-retina="true" class="logo_normal"></a>
                                                <a href="index.php"><img src="img/logo.png" width="120" height="80" alt="City tours" data-retina="true" class="logo_sticky"></a>

                    </div>
                </div>
                <nav class="col-md-9 col-sm-9 col-xs-9" style="padding-top:24px;">
                    <a class="cmn-toggle-switch cmn-toggle-switch__htx open_close" href="javascript:void(0);"><span>Menu mobile</span></a>
                    <div class="main-menu">
                        <div id="header_menu">
                            <img src="img/logo.png" width="120" height="80" alt="City tours" data-retina="true">
                        </div>
                        <a href="#" class="open_close" id="close_in"><i class="icon_set_1_icon-77"></i></a>
                        <ul>
                            <li class="submenu">
                                <a href="about_us.php">About us </a>
                               
                            </li>
                            <li class="submenu">
                                <a href="rooms.php" class="show-submenu">Rooms </a>
                               
                            </li>
                             <li class="submenu">
                                <a href="shirdi.php" class="show-submenu">About Shirdi </a>
                                
                            </li>
                            <li class="submenu">
                                <a href="amenities.php" class="show-submenu">Amenities/Facilities</a>
                               
                            </li>
                            </li>
                            <li class="submenu">
                                <a href="tariff.php" class="show-submenu">Tariff </a>
                               
                            </li>
                             <li class="submenu">
                                <a href="restaurant.php" class="show-submenu">Restaurant </a>
                                
                            </li>
                            <li class="submenu">
                                <a href="contact_us.php" class="show-submenu">Contact US</a>
                               
                            </li>
                           
                                    </div>
                                </div><!-- End menu-wrapper -->
                            </li>
                        </ul>
                    </div><!-- End main-menu -->
                    <ul id="top_tools">
                        <li>
                            <div class="dropdown dropdown-search">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="icon-search"></i></a>
                                <div class="dropdown-menu">
                                    <form>
                                        <div class="input-group">
                                            <input type="text" class="form-control" placeholder="Search...">
                                            <span class="input-group-btn">
                                            <button class="btn btn-default" type="button" style="margin-left:0;">
                                            <i class="icon-search"></i>
                                            </button>
                                            </span>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </li>
                       
                    </ul>
                </nav>
            </div>
        </div><!-- container -->
    </header><!-- End Header -->
