
    <footer>
        <div class="container">
            <div class="row">
                <div class="col-md-7 col-sm-3">
                    <h3>Need help?</h3>
                    <a href="tel://02423255999" id="phone">(02423)255999</a>
                    <a href="mailto:info@hotelsaisiddhishirdi.com" id="email_footer">info@hotelsaisiddhishirdi.com</a>
                </div>
                
                <div class="col-md-3 col-sm-3">
                    <h3>Address:</h3>
                    <ul>
                        <li><a href="#">HOTEL SAI SIDDHI</a></li>
                        <li><a href="#">Shirdi-nagar raod.Opp Sai Ashram</a></li>
                        <li><a href="#">Shirdi-423109</a></li>
                         <li><a href="#">Tal-rahata Dist-Ahmednagar(M.S.)</a></li>
                    </ul>
                </div>
                
            </div><!-- End row -->
            
        </div><!-- End container -->
    </footer><!-- End footer -->
